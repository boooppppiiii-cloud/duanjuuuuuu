"""Meta Shortform Series (SFS) 本地投递包生成与严格预检。"""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Callable
from uuid import uuid4

from PIL import Image, ImageOps

from ..config import get_settings
from ..models import Drama
from ..schemas import MetaSFSRequest
from .drama_library import IMAGE_SUFFIXES, episode_files, files_with_suffix

ALLOWED_GENRES = {
    "Action", "Adventure", "Animated", "Comedy", "Crime", "Documentary",
    "Drama", "Family", "Fantasy", "Historical", "Horror", "Musical",
    "Mystery", "Noir", "Reality", "Romance", "Science fiction", "Sports",
    "Thriller", "Western",
}
SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
ProgressCallback = Callable[[int, str], None]


def _notify_progress(callback: ProgressCallback | None, progress: int, step: str) -> None:
    if callback:
        callback(max(0, min(100, int(progress))), step)


def suggest_slug(title: str, drama_id: int) -> str:
    raw = title.strip().casefold().replace("_", "-").replace(" ", "-")
    slug = re.sub(r"[^a-z0-9-]+", "-", raw)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug or f"short-drama-{drama_id}"


def _binary(name: str) -> str:
    configured = getattr(get_settings(), f"{name}_binary")
    found = shutil.which(configured)
    if not found:
        raise RuntimeError(f"找不到 {name}，请先运行环境体检")
    return found


def inspect_video(path: Path) -> dict:
    command = [_binary("ffprobe"), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30, check=True)
    data = json.loads(result.stdout)
    video = next((item for item in data.get("streams", []) if item.get("codec_type") == "video"), {})
    audio = next((item for item in data.get("streams", []) if item.get("codec_type") == "audio"), {})
    fmt = data.get("format", {})
    return {
        "duration": float(fmt.get("duration") or video.get("duration") or 0),
        "size": int(fmt.get("size") or path.stat().st_size),
        "format": str(fmt.get("format_name") or ""),
        "width": int(video.get("width") or 0),
        "height": int(video.get("height") or 0),
        "video_codec": str(video.get("codec_name") or ""),
        "video_bitrate": int(video.get("bit_rate") or fmt.get("bit_rate") or 0),
        "audio_codec": str(audio.get("codec_name") or ""),
        "audio_channels": int(audio.get("channels") or 0),
        "has_audio": bool(audio),
    }


def _cover_candidates(drama_dir: Path) -> list[Path]:
    candidates: list[Path] = []
    for folder in (drama_dir / "stills", drama_dir / "basemaps", drama_dir):
        candidates.extend(files_with_suffix(folder, IMAGE_SUFFIXES))
    return candidates


def delivery_sources(drama_dir: Path) -> tuple[list[Path], str]:
    """优先使用内容工厂最近一次生成的 Meta 单集，未生成时回退到源文件。"""
    manifest = drama_dir / "generated" / "meta_current.json"
    meta_root = (drama_dir / "generated" / "meta").resolve()
    if manifest.is_file():
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
            files = [Path(value).resolve() for value in data.get("files", [])]
            if files and all(path.is_file() and meta_root in path.parents for path in files):
                return files, "factory_meta_split"
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            pass
    return episode_files(drama_dir), "source_episodes"


def _cover_info(path: Path | None) -> dict:
    if not path:
        return {"path": "", "width": 0, "height": 0}
    with Image.open(path) as image:
        return {"path": str(path), "width": image.width, "height": image.height}


def _stored_cover(value: str) -> Path | None:
    path = Path(value) if value else None
    return path if path and path.is_file() else None


def _cover_issue(path: Path, ratio: float, min_width: int, min_height: int, label: str) -> str:
    try:
        with Image.open(path) as image:
            if image.format not in {"JPEG", "PNG"}:
                return f"{label}仅支持 JPEG 或 PNG"
            width, height = image.size
            if width < min_width or height < min_height or abs(width / height - ratio) > 0.01:
                return f"{label}规格不合规：当前 {width}x{height}"
    except Exception as exc:
        return f"{label}无法读取：{exc}"
    return ""


def preflight(
    drama: Drama,
    payload: MetaSFSRequest,
    delivery: tuple[list[Path], str] | None = None,
    inspect_media: bool = True,
    progress_callback: ProgressCallback | None = None,
) -> dict:
    drama_dir = Path(drama.file_dir)
    sources, source_mode = delivery or delivery_sources(drama_dir)
    expected_total = len(sources) if source_mode == "factory_meta_split" else max(int(drama.total_episode_count or 0), 1)
    effective_description = drama.description.strip() or payload.description.strip()
    effective_genres = drama.genres or payload.genres
    slug = payload.series_slug.strip() or suggest_slug(drama.title, drama.id or 0)
    blockers: list[str] = []
    fixable: list[str] = []
    if not SLUG_RE.fullmatch(slug):
        blockers.append("系列英文标识必须是 kebab-case，只能包含小写字母、数字和短横线")
    if expected_total > 999:
        blockers.append("Meta 文件名只支持三位总集数，单部剧最多 999 集")
    if not sources:
        if source_mode == "factory_meta_split":
            blockers.append("尚无可投递成品，请先在内容工厂选择“Meta 逐集切分”并完成生成")
        else:
            blockers.append("剧目目录中没有可投递的视频")
    elif source_mode != "factory_meta_split" and len(sources) != expected_total:
        blockers.append(f"剧目任务登记为 {expected_total} 集，但当前选择了 {len(sources)} 个视频；Meta 要求视频数量、文件名总集数与系列 CSV 完全一致")
    elif source_mode == "factory_meta_split":
        fixable.append(f"将使用内容工厂生成的 {len(sources)} 个 Meta 单集文件")
    if not effective_description:
        blockers.append("剧目任务缺少剧情简介")
    if not effective_genres or any(item not in ALLOWED_GENRES for item in effective_genres):
        blockers.append("Genre 必须从 Meta 官方类型列表中选择")
    try:
        datetime.strptime(payload.release_date, "%m/%d/%Y")
    except ValueError:
        blockers.append("Release Date 必须使用 MM/DD/YYYY，例如 06/26/2026")

    assets = []
    for index, source in enumerate(sources, 1):
        _notify_progress(
            progress_callback,
            4 + round(index / max(len(sources), 1) * 21),
            f"校验媒体规格 {index}/{len(sources)} · {source.name}",
        )
        target = f"{slug}_ep{index:03}_{expected_total:03}.mp4"
        if not inspect_media:
            if not source.is_file():
                blockers.append(f"第 {index} 集文件不存在或已移动")
            assets.append({
                "episode": index,
                "source": str(source),
                "target": target,
                "info": {"size": source.stat().st_size if source.is_file() else 0},
                "issues": ["将在后台校验媒体规格并自动标准化"],
            })
            continue
        try:
            info = inspect_video(source)
            issues = []
            if not 60 <= info["duration"] <= 180:
                issues.append("时长必须在 60 秒到 3 分钟之间")
                blockers.append(f"第 {index} 集时长 {info['duration']:.1f} 秒，不符合 60 秒到 3 分钟要求")
            if info["size"] > 2 * 1024**3:
                issues.append("文件超过 2GB")
                blockers.append(f"第 {index} 集文件超过 2GB")
            if not _video_dimensions_ready(info): issues.append("将自动转为 1080x1920 竖版")
            if info["video_codec"] != "h264": issues.append("将自动转为 H.264")
            if not _video_bitrate_ready(info): issues.append("将自动提升到至少 2.5Mbps 视频码率")
            if info["audio_codec"] != "aac" or info["audio_channels"] != 2: issues.append("将自动转为 AAC 双声道")
            if issues and not any("时长" in item or "2GB" in item for item in issues):
                fixable.append(f"第 {index} 集：" + "、".join(issues))
            assets.append({"episode": index, "source": str(source), "target": target, "info": info, "issues": issues})
        except Exception as exc:
            blockers.append(f"第 {index} 集媒体信息读取失败：{exc}")
            assets.append({"episode": index, "source": str(source), "target": "", "info": {}, "issues": [str(exc)]})

    vertical_cover = _stored_cover(drama.cover_vertical_path)
    square_cover = _stored_cover(drama.cover_square_path)
    horizontal_cover = _stored_cover(drama.cover_horizontal_path)
    cover_sources = {
        "vertical": _cover_info(vertical_cover),
        "square": _cover_info(square_cover),
        "horizontal": _cover_info(horizontal_cover),
    }
    if not vertical_cover:
        blockers.append("缺少竖版封面：3:4，至少 1440x1920")
    else:
        issue = _cover_issue(vertical_cover, 3 / 4, 1440, 1920, "竖版封面")
        if issue: blockers.append(issue)
    if not square_cover:
        blockers.append("缺少方形封面：1:1，至少 1200x1200")
    else:
        issue = _cover_issue(square_cover, 1.0, 1200, 1200, "方形封面")
        if issue: blockers.append(issue)
    if horizontal_cover:
        issue = _cover_issue(horizontal_cover, 16 / 9, 1920, 1080, "横版封面")
        if issue: blockers.append(issue)
    if vertical_cover and square_cover:
        fixable.append("封面文件名将按 Meta 规范自动统一")
    if sources and not inspect_media:
        fixable.append(f"已登记 {len(sources)} 个视频，媒体规格将在后台校验并自动标准化")
    return {
        "ready": not blockers,
        "series_slug": slug,
        "episode_count": expected_total,
        "source_mode": source_mode,
        "assets": assets,
        "cover_source": cover_sources["vertical"],
        "cover_sources": cover_sources,
        "blockers": list(dict.fromkeys(blockers)),
        "automatic_fixes": list(dict.fromkeys(fixable)),
        "requirements": {
            "video": "MP4/H.264 · 9:16 · 1080x1920 · 视频码率≥2.5Mbps · 60秒-3分钟 · AAC双声道 · 单文件≤2GB",
            "cover": "3:4，至少 1440x1920",
            "square_cover": "1:1，至少 1200x1200",
            "background": "可选；16:9，至少 1920x1080",
            "naming": "<series-name>_epXXX_<total>.mp4，集数和总集数均为三位数字",
        },
    }


def _render_cover(source: Path, target: Path, size: tuple[int, int]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source).convert("RGB") as image:
        ImageOps.fit(image, size, method=Image.Resampling.LANCZOS, centering=(0.5, 0.42)).save(target, quality=94, subsampling=0)


def _video_dimensions_ready(info: dict) -> bool:
    width = int(info.get("width") or 0)
    height = int(info.get("height") or 0)
    return width == 1080 and height == 1920


def _video_bitrate_ready(info: dict) -> bool:
    return int(info.get("video_bitrate") or 0) >= 2_500_000


def _video_stream_copy_ready(info: dict) -> bool:
    return (
        info.get("video_codec") == "h264"
        and _video_dimensions_ready(info)
        and _video_bitrate_ready(info)
    )


def _normalize_video(source: Path, target: Path, info: dict) -> None:
    ffmpeg = _binary("ffmpeg")
    command = [ffmpeg, "-y", "-i", str(source)]
    has_audio = bool(info.get("has_audio"))
    if not has_audio:
        command += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"]
    if _video_stream_copy_ready(info):
        command += [
            "-map", "0:v:0", "-map", "0:a:0" if has_audio else "1:a:0", "-shortest",
            "-c:v", "copy",
        ]
        if has_audio and info.get("audio_codec") == "aac" and info.get("audio_channels") == 2:
            command += ["-c:a", "copy"]
        else:
            command += ["-c:a", "aac", "-b:a", "192k", "-ac", "2", "-ar", "48000"]
        command += ["-movflags", "+faststart", str(target)]
    else:
        command += [
            "-map", "0:v:0", "-map", "0:a:0" if has_audio else "1:a:0", "-shortest",
            "-vf", "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black,fps=25",
            "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-b:v", "3M",
            "-minrate", "3M", "-maxrate", "3M", "-bufsize", "6M", "-x264-params", "nal-hrd=cbr:force-cfr=1",
            "-c:a", "aac", "-b:a", "192k", "-ac", "2", "-ar", "48000", "-movflags", "+faststart", str(target),
        ]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1800)
    if result.returncode != 0:
        raise RuntimeError(result.stderr[-1200:] or "ffmpeg 转码失败")


def _verify_output(path: Path) -> list[str]:
    info = inspect_video(path)
    errors = []
    if "mp4" not in info["format"]: errors.append("视频容器不是 MP4")
    if info["video_codec"] != "h264": errors.append("视频编码不是 H.264")
    if not _video_dimensions_ready(info): errors.append("视频分辨率不是 1080x1920")
    if not _video_bitrate_ready(info): errors.append("视频码率低于 2.5Mbps")
    if not 59.5 <= info["duration"] <= 180.5: errors.append("时长不在 60 秒到 3 分钟之间")
    if info["audio_codec"] != "aac" or info["audio_channels"] != 2: errors.append("音频不是 AAC 双声道")
    if info["size"] > 2 * 1024**3: errors.append("文件超过 2GB")
    return errors


def build_package(
    drama: Drama,
    payload: MetaSFSRequest,
    output_parent: Path | None = None,
    delivery: tuple[list[Path], str] | None = None,
    progress_callback: ProgressCallback | None = None,
) -> tuple[Path, dict]:
    _notify_progress(progress_callback, 2, "读取剧目信息与本机素材")
    check = preflight(drama, payload, delivery, progress_callback=progress_callback)
    if check["blockers"]:
        raise ValueError("；".join(check["blockers"]))
    settings = get_settings()
    slug = check["series_slug"]
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    package_parent = output_parent or settings.media_root / "packages" / "meta_sfs"
    package_root = package_parent / f"{slug}_{stamp}"
    staging_root = package_parent / f".{package_root.name}.building-{uuid4().hex[:8]}"
    series_dir = staging_root / slug
    try:
        _notify_progress(progress_callback, 27, "创建本机 Meta 标准目录")
        series_dir.mkdir(parents=True, exist_ok=False)
        sources, source_mode = delivery or delivery_sources(Path(drama.file_dir))
        total = len(sources) if source_mode == "factory_meta_split" else max(int(drama.total_episode_count or 0), 1)
        description = drama.description.strip() or payload.description.strip()
        genres = drama.genres or payload.genres
        output_checks = []
        for index, source in enumerate(sources, 1):
            name = f"{slug}_ep{index:03}_{total:03}.mp4"
            target = series_dir / name
            _notify_progress(
                progress_callback,
                28 + round((index - 1) / max(total, 1) * 55),
                f"处理第 {index}/{total} 集 · {name}",
            )
            info = inspect_video(source)
            _normalize_video(source, target, info)
            errors = _verify_output(target)
            if errors:
                raise RuntimeError(f"{name} 转码后仍不合规：{'；'.join(errors)}")
            output_checks.append({"file": name, "status": "passed", "info": inspect_video(target)})
            _notify_progress(
                progress_callback,
                28 + round(index / max(total, 1) * 55),
                f"第 {index}/{total} 集已通过规范复核",
            )
            for subtitle_ext in (".srt", ".vtt"):
                subtitle = source.with_suffix(subtitle_ext)
                if subtitle.exists():
                    shutil.copy2(subtitle, series_dir / f"{slug}_ep{index:03}_{total:03}.{payload.locale}{subtitle_ext}")
                    break
            if payload.include_thumbnails:
                thumb = series_dir / f"{slug}_ep{index:03}_{total:03}_thumbnail.jpg"
                result = subprocess.run([_binary("ffmpeg"), "-y", "-ss", "1", "-i", str(target), "-frames:v", "1", "-q:v", "2", str(thumb)], capture_output=True, timeout=90)
                if result.returncode != 0: raise RuntimeError(f"{name} 缩略图生成失败")

        _notify_progress(progress_callback, 86, "生成并校验 Meta 封面")
        cover_sources = check["cover_sources"]
        _render_cover(Path(cover_sources["vertical"]["path"]), series_dir / f"{slug}_cover.jpg", (1440, 1920))
        _render_cover(Path(cover_sources["square"]["path"]), series_dir / f"{slug}_cover_square.jpg", (1200, 1200))
        if cover_sources["horizontal"]["path"]:
            _render_cover(Path(cover_sources["horizontal"]["path"]), series_dir / f"{slug}_background.jpg", (1920, 1080))

        _notify_progress(progress_callback, 91, "写入系列 CSV 元数据")
        series_headers = ["Title", "Description", "Total Number of Episodes", "Locale", "Genre", "Release Date", "Cast List & IG Handles", "Tags", "Geogating", "AI Content", "Dubbed Content"]
        with (series_dir / f"{slug}_series.csv").open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(series_headers)
            writer.writerow([drama.title, description, total, payload.locale, ",".join(genres), payload.release_date, ",".join(payload.cast_list), ",".join(payload.tags), ",".join(payload.geogating), "yes" if drama.is_ai_generated else "no", "yes" if drama.is_dubbed_content else "no"])
        if payload.include_episode_csv:
            with (series_dir / f"{slug}_episodes.csv").open("w", newline="", encoding="utf-8-sig") as stream:
                writer = csv.writer(stream); writer.writerow(["Episode", "Description", "Tags"])
                for index in range(1, total + 1): writer.writerow([index, f"{drama.title} Episode {index}", ",".join(payload.tags)])

        _notify_progress(progress_callback, 96, "执行文件名、集数与目录结构终检")
        expected_video_names = {f"{slug}_ep{index:03}_{total:03}.mp4" for index in range(1, total + 1)}
        actual_video_names = {path.name for path in series_dir.glob("*.mp4")}
        if actual_video_names != expected_video_names:
            raise RuntimeError("Meta 文件名终检失败：视频集数或三位编号不一致")
        expected_required = {
            f"{slug}_series.csv",
            f"{slug}_cover.jpg",
            f"{slug}_cover_square.jpg",
        }
        if not expected_required.issubset({path.name for path in series_dir.iterdir() if path.is_file()}):
            raise RuntimeError("Meta 目录终检失败：缺少系列 CSV 或必填封面")

        manifest = {
            "spec": "Meta Shortform Series MVP Partner Onboarding Instructions v260626",
            "status": "passed", "series_slug": slug, "episode_count": total,
            "validated_at": datetime.now().isoformat(), "checks": output_checks,
            "next_steps": ["上传整个包根目录到 Google Drive", "至少以 Viewer 权限共享给 Meta SFS 服务账号", "登录已获准的 Instagram 账号", "打开 https://www.instagram.com/sfs_tools 并提交 Google Drive 文件夹链接"],
        }
        os.replace(staging_root, package_root)
        _notify_progress(progress_callback, 99, "Meta 合规文件夹已写入本机")
        return package_root, manifest
    except Exception:
        shutil.rmtree(staging_root, ignore_errors=True)
        raise
