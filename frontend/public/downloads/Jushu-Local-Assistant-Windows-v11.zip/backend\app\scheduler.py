from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler
from sqlmodel import Session, select

from .database import engine
from .models import PublishJob
from .services.publisher import execute_publish_job, refresh_publish_status
from .services.metrics import collect_daily_metrics
from .services.radar_search import scan_due_profiles
from .config import get_settings


def scan_publish_jobs() -> None:
    with Session(engine) as session:
        jobs = session.exec(select(PublishJob).where(PublishJob.status == "queued", PublishJob.scheduled_at <= datetime.now()).order_by(PublishJob.scheduled_at)).all()
        for job in jobs:
            execute_publish_job(session, job)


def scan_submitted_jobs() -> None:
    with Session(engine) as session:
        jobs = session.exec(select(PublishJob).where(PublishJob.status == "submitted").order_by(PublishJob.submitted_at)).all()
        for job in jobs[:50]:
            refresh_publish_status(session, job)


def scan_radar_jobs() -> None:
    with Session(engine) as session:
        scan_due_profiles(session)


scheduler = BackgroundScheduler(timezone="Asia/Shanghai")
settings = get_settings()
scheduler.add_job(scan_publish_jobs, "interval", minutes=1, id="publish_scan", replace_existing=True)
scheduler.add_job(scan_submitted_jobs, "interval", minutes=2, id="publish_status_scan", replace_existing=True)
scheduler.add_job(collect_daily_metrics, "cron", hour=3, minute=0, id="daily_metrics", replace_existing=True)
scheduler.add_job(scan_radar_jobs, "cron", hour=settings.radar_daily_scan_hour, minute=20, id="radar_daily_scan", replace_existing=True, max_instances=1, coalesce=True)
