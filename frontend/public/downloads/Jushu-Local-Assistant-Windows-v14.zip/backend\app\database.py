from sqlalchemy import event, inspect, text
from sqlmodel import Session, SQLModel, create_engine

from .config import get_settings


settings = get_settings()
connect_args = {"check_same_thread": False, "timeout": 30} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args)

if settings.database_url.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def configure_sqlite(connection, _):
        cursor = connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


def create_db_and_tables() -> None:
    SQLModel.metadata.create_all(engine)
    # SQLModel 不自带迁移工具；P0 只对单机 SQLite 做向后兼容增列。
    if settings.database_url.startswith("sqlite") and "drama" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("drama")}
        additions = {
            "theater": "VARCHAR NOT NULL DEFAULT ''",
            "description": "VARCHAR NOT NULL DEFAULT ''",
            "is_dubbed_content": "BOOLEAN NOT NULL DEFAULT 0",
            "language": "VARCHAR NOT NULL DEFAULT 'en_US'",
            "promotion_episode_count": "INTEGER NOT NULL DEFAULT 1",
            "total_episode_count": "INTEGER NOT NULL DEFAULT 1",
            "cover_vertical_path": "VARCHAR NOT NULL DEFAULT ''",
            "cover_square_path": "VARCHAR NOT NULL DEFAULT ''",
            "cover_horizontal_path": "VARCHAR NOT NULL DEFAULT ''",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE drama ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "accountstrategy" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("accountstrategy")}
        if "history_text" not in existing:
            with engine.begin() as connection:
                connection.execute(text("ALTER TABLE accountstrategy ADD COLUMN history_text VARCHAR NOT NULL DEFAULT ''"))
    if settings.database_url.startswith("sqlite") and "clip" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("clip")}
        additions = {
            "source_start": "FLOAT NOT NULL DEFAULT 0",
            "source_end": "FLOAT NOT NULL DEFAULT 0",
            "progress": "INTEGER NOT NULL DEFAULT 0",
            "current_step": "VARCHAR NOT NULL DEFAULT 'queued'",
            "error_message": "VARCHAR NOT NULL DEFAULT ''",
            "hit_words": "JSON NOT NULL DEFAULT '[]'",
            "review_note": "VARCHAR NOT NULL DEFAULT ''",
            "reviewed_at": "DATETIME",
            "error_advice": "VARCHAR NOT NULL DEFAULT ''",
            "retry_count": "INTEGER NOT NULL DEFAULT 0",
            "final_video_path": "VARCHAR NOT NULL DEFAULT ''",
            "hook_asset_id": "INTEGER",
            "factory_job_id": "INTEGER",
            "asset_kind": "VARCHAR NOT NULL DEFAULT 'legacy'",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE clip ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "factoryjob" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("factoryjob")}
        additions = {
            "output_modes": "JSON NOT NULL DEFAULT '[\"clean_full\",\"hook_variants\"]'",
            "hooks_per_variant": "INTEGER NOT NULL DEFAULT 1",
            "meta_count": "INTEGER NOT NULL DEFAULT 0",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE factoryjob ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "generatedasset" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("generatedasset")}
        with engine.begin() as connection:
            if "hook_asset_ids" not in existing:
                connection.execute(text("ALTER TABLE generatedasset ADD COLUMN hook_asset_ids JSON NOT NULL DEFAULT '[]'"))
    if settings.database_url.startswith("sqlite") and "account" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("account")}
        additions = {
            "platform_user_id": "VARCHAR NOT NULL DEFAULT ''",
            "avatar_url": "VARCHAR NOT NULL DEFAULT ''",
            "profile_url": "VARCHAR NOT NULL DEFAULT ''",
            "follower_count": "INTEGER NOT NULL DEFAULT 0",
            "last_checked_at": "DATETIME",
            "connected_at": "DATETIME",
            "removed_at": "DATETIME",
            "last_error": "VARCHAR NOT NULL DEFAULT ''",
            "capabilities": "JSON NOT NULL DEFAULT '[]'",
        }
        with engine.begin() as connection:
            if "strategy_id" not in existing:
                connection.execute(text("ALTER TABLE account ADD COLUMN strategy_id INTEGER"))
            if "auto_publish" not in existing:
                connection.execute(text("ALTER TABLE account ADD COLUMN auto_publish BOOLEAN NOT NULL DEFAULT 0"))
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE account ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "metricsnapshot" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("metricsnapshot")}
        additions = {
            "followers": "INTEGER NOT NULL DEFAULT 0",
            "impressions": "INTEGER",
            "clicks": "INTEGER",
            "ctr": "FLOAT",
            "watch_time_seconds": "INTEGER",
            "estimated_revenue": "FLOAT",
            "rpm": "FLOAT",
            "subscribers_gained": "INTEGER",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE metricsnapshot ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "publishjob" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("publishjob")}
        additions = {
            "publish_options": "JSON NOT NULL DEFAULT '{}'",
            "platform_url": "VARCHAR NOT NULL DEFAULT ''",
            "status_checked_at": "DATETIME",
            "submitted_at": "DATETIME",
            "completed_at": "DATETIME",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE publishjob ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "metadeliverypackage" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("metadeliverypackage")}
        additions = {
            "drive_folder_id": "VARCHAR NOT NULL DEFAULT ''",
            "drive_folder_url": "VARCHAR NOT NULL DEFAULT ''",
            "last_error": "VARCHAR NOT NULL DEFAULT ''",
            "uploaded_at": "DATETIME",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE metadeliverypackage ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "socialcomment" in inspect(engine).get_table_names():
        existing = {item["name"] for item in inspect(engine).get_columns("socialcomment")}
        additions = {
            "video_url": "VARCHAR NOT NULL DEFAULT ''",
            "text_zh": "VARCHAR NOT NULL DEFAULT ''",
            "reply_id": "VARCHAR NOT NULL DEFAULT ''",
            "reply_text": "VARCHAR NOT NULL DEFAULT ''",
            "replied_at": "DATETIME",
        }
        with engine.begin() as connection:
            for name, definition in additions.items():
                if name not in existing:
                    connection.execute(text(f"ALTER TABLE socialcomment ADD COLUMN {name} {definition}"))
    if settings.database_url.startswith("sqlite") and "monitoredaccount" in inspect(engine).get_table_names():
        # 监测账号现只维护我方达人和官方引流账号；旧导入记录统一按我方账号处理。
        with engine.begin() as connection:
            connection.execute(text(
                "UPDATE monitoredaccount SET relationship_type = 'own_creator' "
                "WHERE relationship_type NOT IN ('own_creator', 'own_official')"
            ))
            connection.execute(text(
                "UPDATE monitoredaccount SET authorization_status = 'authorized', "
                "allowed_full_series = 1, authorized_regions = '[]', "
                "authorization_start = NULL, authorization_end = NULL"
            ))
    # Per-user operational records were introduced after the original shared MVP.
    # Existing rows are claimed by the developer account during auth bootstrap.
    private_tables = ("clip", "factoryjob", "factoryanalysistask", "generatedasset", "post", "publishjob", "metadeliverypackage")
    if settings.database_url.startswith("sqlite"):
        table_names = set(inspect(engine).get_table_names())
        for table_name in private_tables:
            if table_name not in table_names:
                continue
            existing = {item["name"] for item in inspect(engine).get_columns(table_name)}
            if "owner_user_id" not in existing:
                with engine.begin() as connection:
                    connection.execute(text(f"ALTER TABLE {table_name} ADD COLUMN owner_user_id INTEGER"))


def get_session():
    with Session(engine) as session:
        yield session
